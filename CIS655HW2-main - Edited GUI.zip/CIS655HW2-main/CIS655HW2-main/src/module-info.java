/**
 * 
 */
/**
 * 
 */
module Question2 {
	requires java.desktop;
}
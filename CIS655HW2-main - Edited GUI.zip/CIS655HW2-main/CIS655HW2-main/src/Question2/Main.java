package Question2;

public class Main
{
	
	public static void main(String[] args)
	{
		Hardware cpu1 = new Hardware();
		Interpreter interp = new Interpreter();
		Editor editor = new Editor();
		
		
		// cpu1.testOr();
		//System.out.println(interp.interpret("store r2 r1"));
		
		
	}
	
	
}
